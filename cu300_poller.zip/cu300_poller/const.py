"""Constants for the CU300 Poller integration."""
DOMAIN = "cu300_poller"
CONNECTION_TYPE_SERIAL = "serial"
CONNECTION_TYPE_TCP = "tcp"